// Call the dataTables jQuery plugin
(function($) {
  "use strict"; // Start of use strict
$(document).ready(function() {
  $('#dataTable').DataTable();
});

})(jQuery); // End of use strict
