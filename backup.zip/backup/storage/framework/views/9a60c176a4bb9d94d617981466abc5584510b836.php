<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <!--        <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="#">Events</a>
                  </li>
                  <li class="breadcrumb-item active">View All</li>
                </ol>-->

        <!-- Icon Cards-->
                <div class="row export_btn">
                  <div class="col-xl-12">
                    <div class="col-xl-3 float-right">
                        <form action="<?php echo e(url('user_dashboard/export')); ?>" enctype="multipart/form-data">
                            <button name="export" class="btn btn-outline-primary exp_button" type="submit">Generate Text file</button>
                        </form>
                    </div>
                  </div>
                </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="card mb-12 xl-12">
                    <div class="card-header">
                        <i class="fas fa-table"></i>
                        All Customers</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>CustomerName</th>
                                        <th>FunctionDate</th>
                                        <th>FunctionType</th>
                                        <th>AlbumName</th>
                                        <th>ImageCount</th>
                                        <th>NumberOfSheet</th>
                                        <th>Customer_id</th>
                                        <th>studio_id</th>
                                        <th>ExpiryDate</th>
                                        <th>SelectedPhoto</th>
                                    </tr>
                                </thead>
                                <!-- <tfoot>
                                  <tr>
                                    <th>ID</th>
                                    <th>Event Name</th>
                                    <th>Created date</th>
                                  </tr>
                                </tfoot> -->
                                <tbody>
                                    <?php $__currentLoopData = $allEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->CustomerName); ?></td>
                                        <td><?php echo e($item->FunctionDate); ?></td>
                                        <td><?php echo e($item->FunctionType); ?></td>
                                        <td><?php echo e($item->AlbumName); ?></td>
                                        <td><?php echo e($item->ImageCount); ?></td>
                                        <td><?php echo e($item->NumberOfSheet); ?></td>
                                        <td><?php echo e($item->Customer_id); ?></td>
                                        <td><?php echo e($item->studio_id); ?></td>
                                        <td><?php echo e($item->ExpiryDate); ?></td>
                                        <td><?php echo e($item->SelectedPhoto); ?></td>
                                        <td>
                                 
<!--                                            <a href="javascript:void(0);" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Delete Event">
                                                <i class="fa fa-trash" onclick=deleteCustomer(<?php echo e($item->Customer_id); ?>)></i>
                                            </a>-->
                                            <a href="<?php echo e(url('/user_dashboard/customer/'.$item->Customer_id)); ?>" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Event Photos">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Add Event Modal-->
    <div class="modal fade" id="AddEventModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="AddEventModalData">
                        Add Event
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">
                            &times;
                        </span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="points" class="form-control-label">
                            Event Name:
                        </label>
                        <input type="text" class="form-control" id="event_name" name="event_name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" id="addEvent">Save</a>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $('#addBtn').click(function(){
        //alert('asdasda');
        $('#event_name').val('');
        });
        $('#addEvent').click(function(){
        var id = $('#AddEventModal').data('id');
        var event_name = $('#event_name').val();
        var path = 'add_event';
        if (event_name == '')
        {
        swal('Error', 'Please Enter Event Name', 'error');
        return false;
        }
        $.ajax({
        type: 'POST',
                url: path,
                data: {
                event_id:id,
                        event_name: event_name
                },
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data) {
                var res = $.parseJSON(data);
                if (res.status == 'error'){
                $('#AddEventModal').modal('toggle');
                swal('Error', res.message, 'error');
                $('#event_name').val('');
                } else{
                $('#AddEventModal').modal('toggle');
                $('#event_name').val('');
                swal('Success', res.message, 'success');
                }
                },
                error: function(data) {
                swal('Error', data, 'error');
                }
        });
        });
        function geteventDetails(id){
        var path = "event_details";
        $.ajax({
        type: "POST",
                url: path,
                data: {
                id: id
                },
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(result){
                //console.log(result);
                var res = $.parseJSON(result);
                if (res.status == 'error'){

                } else{
                var data = $.parseJSON(JSON.stringify(res.message));
                $('#AddEventModal').data('id', data.id);
                $('#AddEventModal').find('.modal-title').html('Edit Event');
                $('#event_name').val(data.event_name);
                $('#AddEventModal').modal('show');
                //datatable.reload();
                }
                },
                error: function(){
                alert("Error");
                }
        });
        }
        /*---------DELETE CUSTOMER--------*/
        function deleteCustomer(id){
            
        var path = "deleteCustomer";
        var _this = $(this);
        swal({
        title: "Are you sure to delete this Customer?",
                text: "Your will lost all records of this Customer",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false
        },
                function(isConfirm) {
                if (isConfirm) {
                var data = id;
                $.ajax({
                type: 'POST',
                        url: path,
                        data: {
                        id: data,
                        },
                        headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function(data) {
                        var res = $.parseJSON(data);
                        if (res.status == 'error'){
                        swal('Error', res.message, 'error');
                        } else{
                        $('.sweet-overlay').remove();
                        $('.showSweetAlert ').remove();
                        swal('Success', res.message, 'success');
                        setTimeout(function(){ location.reload(); }, 3000);
                        //$("#ResponseSuccessModal").modal('show');
                        //$("#ResponseSuccessModal #ResponseHeading").text(res.message);
                        }
                        },
                        error: function(data) {
                        swal('Error', data, 'error');
                        }
                });
                } else {

                }
                });
        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>