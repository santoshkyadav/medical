<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Studio APP</title>

        <!-- datepicker CSS-->
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        <!-- Bootstrap core CSS-->
        <link href="<?php echo e(url('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- fontawesome core CSS-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Custom fonts for this template-->
        <link href="<?php echo e(url('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="<?php echo e(url('assets/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">


        <!-- Custom styles for this template-->
        <link href="<?php echo e(url('assets/css/sb-admin.css')); ?>" rel="stylesheet">
      

    </head>

    <body id="page-top">
        <?php 
        $user_detail = $functiondetail[0];
        $studio_id = $user_detail->Studio_Id;
        $customer_id = $user_detail->Customer_Id;
        $customer_details = DB::table('mstcustomer')
        ->where(['Customer_id' => $customer_id,
        'Studio_Id' => $studio_id ])
        ->get();
        $studio_name = DB::table('users')->select('studio_name')
        ->where(['id' => $studio_id ])
        ->get();
        $studio_name = $studio_name[0]->studio_name;
        $customer_name = $customer_details[0]->CustomerName;

         ?>
        <nav class="navbar navbar-expand navbar-dark  static-top">
            <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <a class="navbar-brand mr-1" href="#"><?php echo e($studio_name); ?></a>
            <p style="text-align: right !important; color: #FFF; padding-left: 797px; padding-top: 10px;">Welcome, <?php echo e($customer_name); ?></p>


            <!-- Navbar -->
            <ul class="navbar-nav ml-auto ml-md-0" style="float: right">
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle fa-fw"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                       
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(url('/customer')); ?>" data-toggle="modal" data-target="#logoutModal">Logout</a>
                    </div>
                </li>
            </ul>

        </nav>

