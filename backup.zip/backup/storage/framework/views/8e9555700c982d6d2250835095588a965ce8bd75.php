<div id="wrapper" >
    <!-- Sidebar -->
    <div class="main_menu" >
        <ul class="sidebar navbar-nav" style="background-color: #ffffff !important">
            <li class="nav-item user_nev">
                <a href="#" class="nav-link" title="View Photos"> 
                    <span class="sidebar_menu">Events</span>  
                </a>
                <ul>
                    <?php $__currentLoopData = $functiondetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item user_nev event-names">
                        <a href="#" class="nav-link event_Photos" title="View Photos" data-name="<?php echo e($details->FolderName); ?>"> 
                            <img src="<?php echo e(url('assets/image/Toma4025-Rumax-Folder.ico')); ?>" style="width: 60px;"><span class="sidebar_menu" style="padding-left: 10px;"><?php echo e(ucfirst($details->FolderName)); ?></span>  
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>   
            </li> 
        </ul>
    </div>
