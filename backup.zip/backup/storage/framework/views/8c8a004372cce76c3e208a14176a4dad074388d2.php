<?php $__env->startSection('content'); ?>
<div class="container">
	<h1>User Guide</h1>
<a href="<?php echo e(url('customer/home-page?studio_id='.$functiondetail[0]->Studio_Id.'&customer_id='.$functiondetail[0]->customer_id.'&function_id='.$functiondetail[0]->id)); ?>"><button>Home page</button></a></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer_guide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>