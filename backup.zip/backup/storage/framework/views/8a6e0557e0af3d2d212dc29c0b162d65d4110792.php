  <?php $__env->startSection('content'); ?>
    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Event Name" aria-label="Search" aria-describedby="basic-addon2">
              </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Couple Name" aria-label="Search" aria-describedby="basic-addon2">
              </div>
          </div>
          <div class="col-xl-2 col-sm-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Ocassion" aria-label="Search" aria-describedby="basic-addon2">
              </div>
          </div>
          <div class="col-xl-2 col-sm-6 mb-3">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Event Date" aria-label="Search" aria-describedby="basic-addon2">
              </div>
          </div>
          <div class="col-xl-2 col-sm-6 mb-3">
              <div class="input-group">
                <button class="btn btn-primary">Update</button>
              </div>
          </div>
        </div>

          <!-- Icon Cards-->
        <div class="row">
          <?php $__currentLoopData = $allfolders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card" style="width: 10rem;">
            <img class="card-img-top" src="<?php echo e(url('assets/image/folder.jpg')); ?>" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($item->event_name); ?></h5>
              <p class="card-text"></p>
              <a class="btn btn-primary eventPhotos" title="View Photos" data-id="<?php echo e($item->id); ?>">View Photos
              </a>
            </div>
          </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row" id="photoDiv">
       
        </div>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Your Website 2018</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $('.eventPhotos').on('click',function(){
        var id = $(this).data('id');
        //alert(id);
        $.ajax({
            type: 'POST',
            url: 'getAllEventPhotos',
            data: {
              event_id:id,
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
            success: function(data) {
              var res = $.parseJSON(data);
              if(res.status == 'error'){
                swal('Error',res.message,'error');
                $('#photoDiv').html('');
              }else{
                var result = res.result;
                console.log(result);
                $.each(result,function(i,item)
                {
                  var src='http://localhost/stdio_bkp/storage/app/eventImages';
                  var html = '<div class="col-xl-4 sm-12 md-6" style="margin-top:10px;"><div class="card" style="width: 18rem;"><img class="card-img-top" src="'+src+'/'+item.image+'" alt="Card image cap"><div class="card-body"><h5 class="card-title">'+item.image+'</h5><p class="card-text">Some quick example text to build on the card title and make up the bulk of the cards content.</p><input type="text" class="form-control" placeholder="Add Comment" aria-label="Search" aria-describedby="basic-addon2"></div></div>';
                  $('#photoDiv').append(html);
                });
                //swal('Success',res.message,'success');
              } 
            },
            error: function(data) {
              swal('Error',data,'error');
            }
          });
      });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>