<div id="wrapper" >
    <!-- Sidebar -->
   
    <div class="main_menu">
        <ul class="sidebar navbar-nav" style="background-color: #e8e0c908  !important">
            <li class="nav-item user_nev"> Folders
                <?php 
                $customer_id = Session::get('customer_id');
                $studio_id = Session::get('studio_id');
                $function = DB::table('mstfunction')
                ->where(['Customer_id' => $customer_id, 'Studio_Id' => $studio_id])
                ->ORDERBY('FunctionDate', 'DESC')
                ->first();
                $photosummary = DB::table('customerphotosummary')
                ->where(['Customer_id' => $customer_id,
                'Studio_Id' => $studio_id, 'Function_id' => $function->id])
                ->get()->toArray();
                 ?>
                <ul>
                    <?php $__currentLoopData = $photosummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photocount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($photocount->SelectedPhoto === 0): ?>
                    <li class="nav-item user_nev event-names">
                        <a href="#" class="nav-link event_Photos" title="View Photos" data-name="<?php echo e($photocount->FolderName); ?>"> 
                            <img src="<?php echo e(url('assets/image/Toma4025-Rumax-Folder.ico')); ?>" style="width: 60px;"><span class="sidebar_menu" style="padding-left: 10px;"><?php echo e(ucfirst($photocount->FolderName)); ?></span><span class="count_pics"><?php echo e($photocount->NoofPhoto); ?></span> 
                        </a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item user_nev event-names">
                        <a href="#" class="nav-link event_Photos" title="View Photos" data-name="<?php echo e($photocount->FolderName); ?>"> 
                            <img src="<?php echo e(url('assets/image/Toma4025-Rumax-Folder.ico')); ?>" style="width: 60px;"><span class="sidebar_menu" style="padding-left: 10px;"><?php echo e(ucfirst($photocount->FolderName)); ?></span><span class="count_pics"><?php echo e($photocount->SelectedPhoto.'/'.$photocount->NoofPhoto); ?></span> 
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>   
            </li> 
        </ul>
</div>
<!-- end container -->