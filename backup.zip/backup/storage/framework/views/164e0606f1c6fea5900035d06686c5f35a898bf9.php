<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Studio APP</title>

        <!-- datepicker CSS-->
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        <!-- Bootstrap core CSS-->
        <link href="<?php echo e(url('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- fontawesome core CSS-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Custom fonts for this template-->
        <link href="<?php echo e(url('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="<?php echo e(url('assets/vendor/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">


        <!-- Custom styles for this template-->
        <link href="<?php echo e(url('assets/css/sb-admin.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">

    </head>

    <body id="page-top">
        <div class="container">
            <div class="row" style="margin-top: 70px;">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">Login</div>

                        <div class="panel-body">
                            <?php if(session('error')): ?>                            
                            <div class="alert alert-danger" role="alert">
                                <strong><?php echo e(session('error')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <form class="form-horizontal" method="POST" action="<?php echo e(url('customer/user_giude')); ?>">
                                <?php echo e(csrf_field()); ?>

                                
                                <div class="form-group<?php echo e($errors->has('Cust_Username') ? ' has-error' : ''); ?>">
                                    <label for="Cust_Username" class="col-md-4 control-label">Username</label>

                                    <div class="col-md-6">
                                        <input id="Cust_Username" type="text" class="form-control" name="Cust_Username" value="<?php echo e(old('Cust_Username')); ?>" required autofocus>

                                        <?php if($errors->has('Cust_Username')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Cust_Username')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group<?php echo e($errors->has('Cust_Password') ? ' has-error' : ''); ?>">
                                    <label for="Cust_Password" class="col-md-4 control-label">Password</label>

                                    <div class="col-md-6">
                                        <input id="Cust_Password" type="password" class="form-control" name="Cust_Password" required>

                                        <?php if($errors->has('Cust_Password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('Cust_Password')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-4">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary">
                                            Login
                                        </button>

                                       <!--  <a class="btn btn-link" href="#">
                                            Forgot Your Password?
                                        </a> -->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
