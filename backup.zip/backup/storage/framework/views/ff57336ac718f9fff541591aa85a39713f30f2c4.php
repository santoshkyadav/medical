<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <div class="title m-b-md all-data">
            <a class="btn btn-outline-primary" id="text-file_generate" href="<?php echo e(url('user_dashboard/templatesummary')); ?>">
                Download Template </a> <a class="btn btn-outline-primary" id="software_download" href="<?php echo e(url('user_dashboard/software')); ?>">
                Download Software</a>
            <a class="btn btn-outline-primary" id="client_detail" href="<?php echo e(url('user_dashboard/clientdetail')); ?>">
                Client Detail</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>