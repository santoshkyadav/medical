<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>

        </ol>
        <?php 
        if(!empty($functiondetail)){
        $user_detail = $functiondetail[0];
        $studio_id = $user_detail->Studio_Id;
        $customer_id = $user_detail->Customer_Id;
        $customer_details = DB::table('mstcustomer')
        ->where(['Customer_id' => $customer_id,
        'Studio_Id' => $studio_id ])
        ->get()->toArray();

        }
        else
        {
        $functiondetail = array();
        }
         ?>
        <?php if(!empty($customer_details)): ?>
        <?php 
        $customer = $customer_details[0];

         ?>
        <div class="row form-update">
            <div class="col-sm-3 mb-3">
                <div class="form-group">
                    <label for="functiondate">Function Date</label>
                    <input type="text" class="form-control" id="functiondate" aria-label="Search" aria-describedby="basic-addon2" value="<?php echo e($customer->FunctionDate); ?>">
                </div>
            </div>
            <div class="col-sm-3 mb-3">
                <div class="form-group">
                    <label for="functiontype">Function Type</label>
                    <input type="text" class="form-control" id="functiontype" placeholder="Function Type" aria-label="Search" aria-describedby="basic-addon2" value="<?php echo e($customer->FunctionType); ?>">
                </div>
            </div>
            <div class="col-sm-3 mb-3">
                <div class="form-group">
                    <label for="functionname">Function Name</label>
                    <input type="text" class="form-control" id="functionname" placeholder="Function Name" aria-label="Search" aria-describedby="basic-addon2" value="<?php echo e($customer->AlbumName); ?>">
                </div>
            </div>
            <div class="col-sm-3 mb-3">
                <div class="form-group">
                    <label for="otherremark">Other Remark</label>
                    <input type="text" class="form-control" id="otherremark" placeholder="Other Remark" aria-label="Search" aria-describedby="basic-addon2" value="<?php echo e($customer->Remark); ?>">
                </div>
            </div>
            <div class="col-sm-3 mb-3">
                <div class="input-group">
                    <button type="submit" class="btn btn-primary function_data">Update</button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="cont_images row" style="background-color: #8e204e; color: #fff;">
            <h3 class="col-sm-9">Images </h3><span class="total_image float-right col-sm-3" style="text-align: right; padding-top: 10px; font-weight: 600;">Total Images: <?php echo e($customer->ImageCount); ?></span>
        </div>
        <div class="row" id="photo_Div">

        </div>
    </div>
</div>
<!-- /.container-fluid -->

<!-- Sticky Footer -->


<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">

//========= datepicker in input type:text==== //
$(function () {
    $("#functiondate").datepicker({
        dateFormat: "yy-mm-dd",
        orientation: "bottom",
    });
});

//=========  block right click on images==== //
//$(function () {
//    $(this).bind("contextmenu", function (e) {
//        e.preventDefault();
//    });
//});

//=========DISPLAY IMAGES ACCORDING TO EVENT======= //
$('.event_Photos').on('click', function () {
    var folder_name = $(this).data('name');
//        alert(folder_name);
    $.ajax({
        type: 'POST',
        url: 'functionPhotos',
        data: {
            'event_name': folder_name
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        },
        success: function (data) {
            var res = $.parseJSON(data);
            console.log(res);
            if (res.status === 'error') {
                swal('Error', res.message, 'error');
                $('#photo_Div').html('');
            } else {
                var result = res.result;
                console.log(result[1].Status);
                $('#photo_Div').html('');
                $.each(result, function (i, item)
                {

                    var src = '<?php echo e(url("/assets/image")); ?>';

                    if (item.Status === '1') {
                        var html = '<div class="col-md-3 sm-10" style="margin-top:10px;"><div id="card_' + item.FunctionId + '" class="card cancel_card"><img class="card-img-top" src="' + src + '/' + item.FileName + '" alt="Card image cap"><div class="card-body"><div id="comment_Div' + item.FunctionId + '" data-id="' + item.FunctionId + '"><div class="row comment-div"><div class="col-sm-8 comment_input"><input type="text" class="form-control add_comment" placeholder="Add Comment" value="' + item.Comment + '" aria-label="Search" aria-describedby="basic-addon2"></div><div class="col-sm-2"><button type="button" data-toggle="tooltip" data-placement="bottom" class="comment_btn" onclick=commentPhoto(' + item.FunctionId + ')><i class="far fa-comments"></i></button></div><div class="col-sm-2"><button class="select_btn selected_btn" id="select_btn_' + item.FunctionId + '" onclick=selectPhoto(' + item.FunctionId + ')><i class="fa fa-times"></i></button></div></div></div><div id="lastComment' + item.FunctionId + '"></div></div></div>';
//                        $('#select_btn_' + item.FunctionId).addClass('selected_btn');
                    } else {
                        var html = '<div class="col-md-3 sm-10" style="margin-top:10px;"><div class="card" id="card_' + item.FunctionId + '"><img class="card-img-top" src="' + src + '/' + item.FileName + '" alt="Card image cap"><div class="card-body"><div id="comment_Div' + item.FunctionId + '" data-id="' + item.FunctionId + '"><div class="row comment-div"><div class="col-sm-8 comment_input"><input type="text" class="form-control add_comment" placeholder="Add Comment" value="' + item.Comment + '" aria-label="Search" aria-describedby="basic-addon2"></div><div class="col-sm-2"><button type="button" data-toggle="tooltip" data-placement="bottom" class="comment_btn" onclick=commentPhoto(' + item.FunctionId + ')><i class="far fa-comments"></i></button></div><div class="col-sm-2"><button class="select_btn" id="select_btn_' + item.FunctionId + '" onclick=selectPhoto(' + item.FunctionId + ')><i class="fa fa-check"></i></button></div></div></div><div id="lastComment' + item.FunctionId + '"></div></div></div>';
                    }
                    $('#photo_Div').append(html);
                });
                //swal('Success',res.message,'success');
            }
        },
        error: function (data) {
            swal('Error', data, 'error');
        }
    });
});

//=========Tooltip=======//
$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});

$('.function_data').on('click', function () {
    var functiondate = $('#functiondate').val();
    var functiontype = $('#functiontype').val();
    var functionname = $('#functionname').val();
    var otherremark = $('#otherremark').val();
    //alert(id);
    $.ajax({
        type: 'GET',
        url: 'customer_function_update',
        data: {
            function_date: functiondate, function_type: functiontype, function_name: functionname, other_remark: otherremark
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        },
        success: function (data) {
            var res = $.parseJSON(data);
            console.log(res);
            if (res.status === 'error') {
                swal('Error', res.message, 'error');
                $('#photoDiv').html('');
            } else {
                var result = res.result;
                console.log(result[0]);
//                $('#functiondate').val(result[0].function_date);
//                $('#functiontype').val(result[0].function_type);
//                $('#functionname').val(result[0].function_name);
//                $('#otherremark').val(result[0].other_remark);
                swal('Success', res.message, 'success');

            }
        },
        error: function (data) {
            swal('Error', data, 'error');
        }
    });
});

//=========COMMENT ON PICS==== //
function commentPhoto(id)
{
    var comment = $('#comment_Div' + id + ' input').val();
    var path = "Comment_photo";
    $.ajax({
        type: 'POST',
        url: path,
        data: {
            id: id,
            comment: comment,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        },
        success: function (data) {
            var res = $.parseJSON(data);
            if (res.status === 'error') {
                swal('Error', res.message, 'error');
            } else {
//                $('#lastComment'+id+' span').html('Last Comment :'+comment);
                $('#comment_Div' + id + ' input').val(comment);
                swal('Success', res.message, 'success');
                //setTimeout(function(){ location.reload(); }, 3000);
            }
        },
        error: function (data) {
            swal('Error', data, 'error');
        }
    });
}

//=========SELECT PICS==== //
function selectPhoto(id)
{
    var path = "Select_photo";
    $.ajax({
        type: 'POST',
        url: path,
        data: {
            id: id,
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        },
        success: function (data) {
            var res = $.parseJSON(data);
            if (res.status === 'error') {
                swal('Error', res.message, 'error');

            } else if (res.status === 'success') {
                $('#select_btn_' + id).addClass('selected_btn');
                $('#card_' + id).addClass('cancel_card');
                $("#select_btn_ " + id + "> i").removeClass('fa-check');
                $("#select_btn_" + id + " > i").addClass('fa-times');
                swal('Success', res.message, 'success');
                //setTimeout(function(){ location.reload(); } , 3000);
            } else {
                $('#select_btn_' + id).removeClass('selected_btn');
                $('#card_' + id).removeClass('cancel_card');
                $("#select_btn_ " + id + "> i").removeClass('fa-times');
                $("#select_btn_" + id + " > i").addClass('fa-check');
                swal('Warning', res.message, 'warning');
            }
        },
        error: function (data) {
            swal('Error', data, 'error');
        }
    });
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>