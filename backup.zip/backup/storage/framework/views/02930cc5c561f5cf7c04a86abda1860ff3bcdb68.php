<?php $__env->startSection('content'); ?>

<div id="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-xl-12">
                <div class="card mb-12 xl-12">
                    <div class="card-header">
                        <i class="fas fa-table"></i>template
                       </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Template Name</th>
                                        <th>Description</th>
                                        <th>File Name</th>
                                    </tr>
                                </thead>
                                <!-- <tfoot>
                                  <tr>
                                    <th>ID</th>
                                    <th>Event Name</th>
                                    <th>Created date</th>
                                  </tr>
                                </tfoot> -->
                                <tbody>
                                    <?php $__currentLoopData = $template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->template_name); ?></td>
                                        <td><?php echo e($item->description); ?></td>
                                        <td><?php echo e($item->file_name); ?></td>
                                        <td>
                                            <a href="#" class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Event Photos">
                                                <i class="fa fa-download" aria-hidden="true"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>