
<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

<div class="panel panel-default form_field">
  <div class="panel-heading"><h2>Add Template</h2></div>
  <div class="panel-body">
  	<!-- form -->
  	<?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
  </div>
  <?php endif; ?>

  <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">

Select file 
<input name="ufile" type="file" id="ufile" />

<input type="submit" name="Submit" value="Upload" />

 </form>
   <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Your Website 2018</span>
      </div>
    </div>
  </footer>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>