  <?php $__env->startSection('content'); ?>
    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

          <!-- Icon Cards-->
        <div class="row">
          <?php $__currentLoopData = $allEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card" style="width: 10rem;">
            <img class="card-img-top" src="<?php echo e(url('assets/image/folder.jpg')); ?>" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($item->event_name); ?></h5>
              <p class="card-text"></p>
              <a href="<?php echo e(url('event').'/'.$item->id.'/photos'); ?>" class="btn btn-primary" title="View Photos">View Photos
              </a>
            </div>
          </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Your Website 2018</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>