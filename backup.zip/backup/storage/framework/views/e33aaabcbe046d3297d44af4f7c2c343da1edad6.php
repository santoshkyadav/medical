<?php $__env->startSection('content'); ?>

<div id="content-wrapper">
    <div class="container-fluid">
         <!-- Breadcrumbs-->
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="<?php echo e(url('user_dashboard')); ?>">Dashboard</a>
                  </li>
                  <li class="breadcrumb-item active">Template Summary</li>
                </ol>


        <div class="row">
            <div class="col-xl-12">
                <div class="card mb-12 xl-12">
                    <div class="card-header">
                        <i class="fas fa-table"></i>template Summary
                        <a href="<?php echo e(url('user_dashboard')); ?>"class="back-icon float-right">Back <i class="fa fa-undo" aria-hidden="true"></i></a>
                       </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Upload Date</th>
                                        <th>No of Template</th>
                                        <th>Total FileSize</th>
                                        <th>View Files</th>
                                    </tr>
                                </thead>
                                <!-- <tfoot>
                                  <tr>
                                    <th>ID</th>
                                    <th>Event Name</th>
                                    <th>Created date</th>
                                  </tr>
                                </tfoot> -->
                                <tbody>

                                    <?php if($templatesummary[0]->UploadDate == ''): ?>
                                     <tr>
                                        <td colspan= '4' style="text-align: center;"><i>No templates found in Table</i></td>
                                        
                                    </tr>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $templatesummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php 
                                    $old_date = date_create($item->UploadDate);
                                       $date =  date_format($old_date,"d M Y");
                                     ?>
                                        <td><?php echo e($date); ?></td>
                                        <td><?php echo e($item->NoOfTemplate); ?></td>
                                        <td><?php echo e($item->TotalFileSize); ?> MB</td>
                                        <td>
                                            <a class="m-portlet__nav-link btn m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill" title="Event Photos" href="<?php echo e(url('user_dashboard/templatesummary/template/'.$item->UploadDate)); ?>">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>