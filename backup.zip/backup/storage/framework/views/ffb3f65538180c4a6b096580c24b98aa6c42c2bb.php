
<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('/admin_dashboard')); ?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Distributer</li>
    </ol>
  </div>
  <!-- /.container-fluid -->
  <?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
  </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="card mb-12 xl-12">
        <div class="card-header">
          <i class="fas fa-table"></i>Distributer Table
              <a href="<?php echo e(url('admin_dashboard')); ?>"class="back-icon float-right">Back <i class="fa fa-undo" aria-hidden="true"></i></a> 

              <a href="#" class="update_studio float-right btn btn-primary"  data-toggle="modal" data-target="#adddistributor" title="Update Customer" style="margin-right: 3%; background: #f3f3f3; color: #007bff; border: 2px solid #007bff;">
                      <i class="fa fa-plus" ></i> Add Distributor
              </a> 
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Distributer Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i= 1;
                 ?>
                <?php $__currentLoopData = $distributer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($function->Name); ?></td>
                  
                  <td>
                    <a href="<?php echo e(url('admin/distributer/delete='.$function->distributer_id)); ?>" title="Delete Distributer">
                      <i class="fa fa-trash"></i>
                    </a>
                    <a href="#" class="update_studio"  data-toggle="modal" data-target="<?php echo e('#newModel'.$function->distributer_id); ?>" title="Update Distributer">
                      <i class="far fa-edit"></i>
                    </a> 
                    <!-- model -->
                    <div class="modal fade" id="<?php echo e('newModel'.$function->distributer_id); ?>" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Update Distributor Name</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button> 
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(url('admin/distributer?id='.$function->distributer_id)); ?>">
                              <?php echo e(csrf_field()); ?>

                              <?php  
                              $res=DB::table('distributer')->where('distributer_id', $function->distributer_id)->get()->toArray();
                            //print_r($res[0]->distributer_id);

                               ?>
                              <div class="form-group">
                                <label for="functiondate">Distributer Name</label>
                                <input type="text" class="form-control" name="distributorname" value="<?php echo e($res[0]->Name); ?>">
                              </div>
                              
                              
                               
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- end model -->

                  </td>
                </tr>
                <?php 
                $i++;
                 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- model -->
                    <div class="modal fade" id="adddistributor" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Add Distributor </h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button> 
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(url('admin/adddistributer')); ?>">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group">
                                <label for="functiondate">Distributor Name</label>
                                <input type="text" class="form-control" name="distributorname">
                              </div> 
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary" >Add</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- end model -->

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Your Website 2018</span>
      </div>
    </div>
  </footer>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(function () {
    $("#expirydate").datepicker({
        dateFormat: "yy-mm-dd",
        orientation: "bottom",
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>