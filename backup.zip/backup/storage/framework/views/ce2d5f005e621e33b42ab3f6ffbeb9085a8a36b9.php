    <div id="wrapper">
      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('/admin_dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('admin/customers')); ?>">
            <span>Customers Table</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('admin/eventname')); ?>">
            <span>Function Type&Name</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('admin/paymentdetails')); ?>">
            <span>Payment Details</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('admin/paymentform')); ?>">
            <span>Cash Payment Form</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(url('admin/addtemplate')); ?>">
            <span>Add Template</span>
          </a>
        </li>
      </ul>
