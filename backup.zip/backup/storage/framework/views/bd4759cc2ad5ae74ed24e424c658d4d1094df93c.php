<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Customers</li>
    </ol>
  </div>
  <!-- /.container-fluid -->
  <?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
  </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="card mb-12 xl-12">
        <div class="card-header">
          <i class="fas fa-table"></i>Payment Table
          <a href="<?php echo e(url('admin_dashboard')); ?>"class="back-icon float-right">Back <i class="fa fa-undo" aria-hidden="true"></i></a>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Studio Name</th>
                  <th>Address</th>                
                  <th>City</th>
                  <th>State</th>
                  <th>Remark</th>
                  <th>Amount Paid For</th>
                  <th>Collection By</th>
                  <th>Collected By</th>
                  <th>Delivery Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i= 1;
                 ?>
                <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userList_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($userList_val->Studio); ?></td>
                  <td><?php echo e($userList_val->MobileNo); ?></td>
                  <td><?php echo e($userList_val->address); ?></td>
                  <td><?php echo e($userList_val->city); ?></td>
                  <td><?php echo e($userList_val->state); ?></td>
                  <td><?php echo e($userList_val->remark); ?></td>
                  <?php if($userList_val->amountpaidfor == 1): ?>
                  <td>Photo Selection Software</td>
                  <?php elseif($userList_val->amountpaidfor == 2): ?>
                  <td>Website</td>
                  <?php elseif($userList_val->amountpaidfor == 3): ?>
                  <td>Design Software</td>
                  <?php else: ?>
                  <td>Ebook</td>
                  <?php endif; ?>
                   <?php if($userList_val->collectionby == 1): ?>
                  <td>Kd Surat</td>
                  <?php elseif($userList_val->collectionby == 2): ?>
                  <td>Kd Lucknow</td>
                  <?php else: ?>
                  <td>ElationSoft</td>
                  <?php endif; ?>
                  <td><?php echo e($userList_val->collectedby); ?></td>
                  <?php if($userList_val->deliverystatus == 1): ?>
                  <td>Website</td>
                  <?php elseif($userList_val->deliverystatus == 2): ?>
                  <td>Software</td>
                  <?php else: ?>
                  <td>Hosting</td>
                  <?php endif; ?>
                  <td>
                  <a href="#" title="View customer">
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </a>
                    <a href="#" class="update_studio" data-id="<?php echo e($userList_val->id); ?>" data-toggle="modal" data-target="<?php echo e('#newModel'.$userList_val->id); ?>" title="Update payment">
                      <i class="far fa-edit"></i>
                    </a> 
                  </td>
                </tr>
                <?php 
                $i++;
                 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Your Website 2018</span>
      </div>
    </div>
  </footer>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>