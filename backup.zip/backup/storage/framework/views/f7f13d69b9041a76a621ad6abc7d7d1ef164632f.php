<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('/admin_dashboard')); ?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?php echo e(url('admin/customers')); ?>">Customer</a>
      </li>
      <li class="breadcrumb-item active">Function </li>
    </ol>
  </div>
  <!-- /.container-fluid -->
  <?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
  </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="card mb-12 xl-12">
        <div class="card-header">
          <i class="fas fa-table"></i>Event Name&Type  Table
          <a href="<?php echo e(url('admin/customers')); ?>"class="back-icon float-right">Back <i class="fa fa-undo" aria-hidden="true"></i></a>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Studio Id</th>
                  <th>Customer Id</th>                
                  <th>Function Date</th>
                  <th>Function Type</th>
                  <th>Album Name</th>
                  <th>Image Count</th>
                  <th>Remark</th>
                  <th>No. Of Sheet</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i= 1;
                 ?>
                <?php $__currentLoopData = $function_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($function->Studio_Id); ?></td>
                  <td><?php echo e($function->customer_id); ?></td>
                  <td><?php echo e($function->FunctionDate); ?></td>
                  <td><?php echo e($function->FunctionType); ?></td>
                  <td><?php echo e($function->AlbumName); ?></td>
                  <td><?php echo e($function->ImageCount); ?></td>
                  <td><?php echo e($function->Remark); ?></td>
                  <td><?php echo e($function->NumberOfSheet); ?></td>
                  <?php if($function->status): ?>
                  <td>Expired</td>
                  <?php else: ?>
                  <td>UnExpired</td>
                  <?php endif; ?>
                  <td>
                    <a href="<?php echo e(url('admin/function/Images?function_id='.$function->id)); ?>" title="View Images">
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </a>
                    <a href="<?php echo e(url('admin/customer/deletefunctions?customer_id='.$function->customer_id.'&function_id='.$function->id)); ?>" title="Delete Images">
                      <i class="fa fa-trash"></i>
                    </a>
                    <a href="#" class="update_studio" data-id="<?php echo e($function->id); ?>" data-toggle="modal" data-target="<?php echo e('#newModel'.$function->id); ?>" title="Update Images">
                      <i class="far fa-edit"></i>
                    </a> 
                    <!-- model -->
                    <div class="modal fade" id="<?php echo e('newModel'.$function->id); ?>" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Update Function Name</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button> 
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(url('admin/customer/updatefunctions?customer_id='.$function->customer_id.'&function_id='.$function->id)); ?>">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group">
                                <label for="functiondate">Function Date:</label>
                                <input type="text" class="form-control" name="functiondate" value="<?php echo e($function->FunctionDate); ?>">
                              </div>
                              <div class="form-group">
                                <label for="functiontype">Function Type:</label>
                                <input type="text" class="form-control" name="functiontype" value="<?php echo e($function->FunctionType); ?>">
                              </div>
                              <div class="form-group">
                                <label for="albumname">Album Name:</label>
                                <input type="text" class="form-control" name="albumname" value="<?php echo e($function->AlbumName); ?>">
                              </div> 
                              <div class="form-group">
                                <label for="imagecount">Image Count</label>
                                <input type="text" class="form-control" name="imagecount" value="<?php echo e($function->ImageCount); ?>">
                              </div>
                              <div class="form-group">
                                <label for="remark">Remark:</label>
                                <input type="text" class="form-control" name="remark" value="<?php echo e($function->Remark); ?>">
                              </div>
                              <div class="form-group">
                                <label for="noofsheet">No of Sheet:</label>
                                <input type="text" class="form-control" name="noofsheet" value="<?php echo e($function->NumberOfSheet); ?>">
                              </div>
                               <div class="form-group">
                                <label for="status">Status:</label>
                                <?php if($function->status): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="0" checked>Expired
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="1">UnExpired
                                </label>
                                <?php else: ?>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="0">Expired
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="1" checked>UnExpired
                                </label>
                                <?php endif; ?>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- end model -->

                  </td>
                </tr>
                <?php 
                $i++;
                 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Your Website 2018</span>
      </div>
    </div>
  </footer>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(function () {
    $("#expirydate").datepicker({
        dateFormat: "yy-mm-dd",
        orientation: "bottom",
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>