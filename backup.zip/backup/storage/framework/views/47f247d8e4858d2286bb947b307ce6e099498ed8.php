<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(url('public/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS-->
    <!-- <link href="<?php echo e(url('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/sweetalert.css')); ?>">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.name', 'Studio Name')); ?>

                    </a>
                </div>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Login</div>

                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(url('admin_login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <strong><?php echo e(session('error')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <strong><?php echo e(session('success')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <div class="form-group<?php echo e($errors->has('mobile_no') ? ' has-error' : ''); ?>">
                                <label for="mobile_no" class="col-md-4 control-label">mobile_no</label>

                                <div class="col-md-6">
                                    <input id="mobile_no" type="text" class="form-control" name="mobile_no" value="<?php echo e(old('mobile_no')); ?>" required autofocus>

                                    <?php if($errors->has('mobile_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('mobile_no')); ?></strong> </span>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>

                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label for="password" class="col-md-4 control-label">Password</label>

                                    <div class="col-md-6">
                                        <input id="password" type="password" class="form-control" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                        <?php if(session('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e(session('password')); ?></strong>
                                        </span>
                                        
                                        <?php endif; ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-4">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary">
                                            Login
                                        </button>

                                        <a class="btn btn-link" href="<?php echo e(url('forgetPassword')); ?>">
                                            Forgot Your Password?
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(url('public/js/app.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script> -->

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <script type="text/javascript">
        $('#verify_number').on('click', function(){
            alert('okkk');
            $.ajax({
                type: 'POST',
                url: 'verifyStudio',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response){

                    var res = $.parseJSON(response);
                    var message = res.MessageData[0].Number;
                    console.log(message);
                    var HTML = '<p>Your One Time Passcode has been sent to  <strong>Mobile No.: +' + message + '</strong></p>';
                    $('#confirm_message').append(HTML);
                }
            });
        });
        
    </script>

</body>
</html>