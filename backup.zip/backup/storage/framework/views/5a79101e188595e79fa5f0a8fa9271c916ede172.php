<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Customers</li>
    </ol>
  </div>
  <!-- /.container-fluid -->
  <?php if(session('error')): ?>
  <div class="alert alert-danger" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
  </div>
  <?php endif; ?>
  <?php if(session('success')): ?>
  <div class="alert alert-success" role="alert">
    <strong><?php echo e(session('success')); ?></strong>
  </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-xl-12">
      <div class="card mb-12 xl-12">
        <div class="card-header">
          <i class="fas fa-table"></i>Payment Table
          <a href="<?php echo e(url('admin_dashboard')); ?>"class="back-icon float-right">Back <i class="fa fa-undo" aria-hidden="true"></i></a>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Payment Date</th>
                  <th>Subscription Tenure (In Months)</th>                
                  <th>StartDate</th>
                  <th>Expiry Date</th>
                  <th>Studio Name (Id)</th>
                  <th>Amount Paid</th>
                  <th>StudioMob.No.</th>
                  <th>Payment Methord</th>
                  <th>Payment Status</th>
                  <th>Remark</th>
                  <th>AmountPaidFor</th>
                  <th>Collection Place</th>
                  <th>Collected By</th>
                  <th>Delivery status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i= 1;
                 ?>
                <?php $__currentLoopData = $paymentdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i); ?></td>
                  <td><?php echo e($payment_val->PaymentDate); ?></td>
                  <td><?php echo e($payment_val->SubscriptionTenure); ?></td>
                  <td><?php echo e($payment_val->StartDate); ?></td>
                  <td><?php echo e($payment_val->ExpiryDate); ?></td>
                  <?php 
                  $std = DB::table('studio')->where('id', '=', $payment_val->Studio_id)->get()->toArray();
                  if(!empty($std)){
                   ?>
                  <td><?php echo e($std[0]->studio_name); ?> (<?php echo e($payment_val->Studio_id); ?>)</td><?php 
                  }else{
                   ?>
                  <td><?php echo e($payment_val->Studio_id); ?></td><?php 
                  }
                   ?>
                  <td><?php echo e($payment_val->AmountPaid); ?></td>
                  <td><?php echo e($payment_val->StudioMobileNumber); ?></td>
                   <?php if($payment_val->PaymentMethord == 1): ?>
                  <td>Online</td>
                  <?php elseif($payment_val->PaymentMethord == 2): ?>
                  <td>Bank Deposite</td>
                  <?php else: ?>
                  <td>At Counter(Cash)</td>
                  <?php endif; ?>
                  <?php if($payment_val->PaymentStatus == 0): ?>
                  <td>Pending</td>
                  <?php elseif($payment_val->PaymentStatus == 1): ?>
                  <td>Success</td>
                  <?php else: ?>
                  <td>Failed</td>
                  <?php endif; ?>
                  <td><?php echo e($payment_val->Remark); ?></td>
                  <td><?php echo e($payment_val->AmountPaidFor); ?></td>
                  <?php if($payment_val->CollectionPlace == 1): ?>
                  <td>KD Surat</td>
                  <?php elseif($payment_val->CollectionPlace == 2): ?>
                  <td>KD Lucknow</td>
                  <?php else: ?>
                  <td>ElationSoft</td>
                  <?php endif; ?>
                  <td><?php echo e($payment_val->CollectedBy); ?></td>
                  <td><?php echo e($payment_val->Deliverystatus); ?></td>
                  <td>
                  <a href="#" title="View customer">
                      <i class="fa fa-eye" aria-hidden="true"></i>
                    </a>
                    <a href="#" class="update_studio" data-id="<?php echo e($payment_val->Payment_Id); ?>" data-toggle="modal" data-target="<?php echo e('#newModel'.$payment_val->Payment_Id); ?>" title="Update payment">
                      <i class="far fa-edit"></i>
                    </a> 
                    <div class="modal fade" id="<?php echo e('newModel'.$payment_val->Payment_Id); ?>" role="dialog">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Update Payment</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button> 
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo e(url('admin/paymentdetails?update='.$payment_val->Payment_Id)); ?>">
                              <?php echo e(csrf_field()); ?>

                              <div class="form-group">
                                <label for="paymentdate">Payment Date:</label>
                                <input type="text" class="form-control" name="paymentdate" value="<?php echo e($payment_val->PaymentDate); ?>">
                              </div>
                              <div class="form-group">
                                <label for="SubscriptionTenure">Subscription Tenure:</label>
                                <input type="text" class="form-control" name="SubscriptionTenure" value="<?php echo e($payment_val->SubscriptionTenure); ?>">
                              </div>
                              <div class="form-group">
                                <label for="StartDate">Start Date:</label>
                                <input type="text" class="form-control" name="StartDate" value="<?php echo e($payment_val->StartDate); ?>">
                              </div> 
                              <div class="form-group">
                                <label for="ExpiryDate">Expiry Date:</label>
                                <input type="text" class="form-control" name="ExpiryDate" value="<?php echo e($payment_val->ExpiryDate); ?>">
                              </div>
                              <div class="form-group">
                                <label for="Studio_id">Studio Id:</label>
                                <input type="text" class="form-control" name="Studio_id" value="<?php echo e($payment_val->Studio_id); ?>">
                              </div>
                              <div class="form-group">
                                <label for="AmountPaid">Amount Paid:</label>
                                <input type="text" class="form-control" name="AmountPaid" value="<?php echo e($payment_val->AmountPaid); ?>">
                              </div>
                              <div class="form-group">
                                <label for="StudioMobileNumber">Studio Mob.No.:</label>
                                <input type="text" class="form-control" name="StudioMobileNumber" value="<?php echo e($payment_val->StudioMobileNumber); ?>">
                              </div>
                               <div class="form-group">
                                <label for="PayMethod">Payment Option:</label>
                                <?php if($payment_val->PaymentMethord == 1): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="1" checked>Online
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="2">Bank Deposite
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="3">At Counter(Cash)
                                </label>
                                <?php elseif($payment_val->PaymentMethord == 2): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="1">Online
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="2" checked>Bank Deposite
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="3">At Counter(Cash)
                                </label>
                                <?php else: ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="1">Online
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="2">Bank Deposite
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PayMethod" value="3" checked>At Counter(Cash)
                                </label>
                                <?php endif; ?>
                              </div>
                              <div class="form-group">
                                <label for="PaymentStatus">Status:</label>
                                <?php if($payment_val->PaymentStatus == 0): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="0" checked>Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="1">Success
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="2">Failed
                                </label>
                                <?php elseif($payment_val->PaymentStatus == 1): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="0">Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="1" checked>Success
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="2">Failed
                                </label>
                                <?php else: ?>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="0">Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="1">Success
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="PaymentStatus" value="2" checked>Failed
                                </label>
                                <?php endif; ?>
                              </div>
                              <div class="form-group">
                                <label for="functiondate">Remark:</label>
                                <textarea class="form-control" name="remark"><?php echo e($payment_val->Remark); ?></textarea>
                              </div>
                               <div class="form-group">
                                <label for="status">Delivery Status:</label>
                                <?php if($payment_val->Deliverystatus == 'pending'): ?>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="pending" checked>Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="websitedeliver">Website Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="softwaredeliver">Software Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="hosting">Hosting
                                </label>
                                <?php elseif($payment_val->Deliverystatus == 'websitedeliver'): ?>
                                <input type="radio" name="status" value="pending">Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="websitedeliver" checked>Website Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="softwaredeliver">Software Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="hosting">Hosting
                                </label>
                                <?php elseif($payment_val->Deliverystatus == 'softwaredeliver'): ?>
                                <input type="radio" name="status" value="pending">Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="websitedeliver">Website Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="softwaredeliver" checked>Software Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="hosting">Hosting
                                </label>
                                <?php elseif($payment_val->Deliverystatus == 'hosting'): ?>
                                <input type="radio" name="status" value="pending">Pending
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="websitedeliver">Website Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="softwaredeliver">Software Delivered
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="status" value="hosting" checked>Hosting
                                </label>
                                <?php endif; ?>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Update</button>
                            </form> 
                        </div>
                      </div>
                    </div>
                    <!-- end model -->
                  </td>
                </tr>
                <?php 
                $i++;
                 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Sticky Footer -->
  <footer class="sticky-footer">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright © Your Website 2018</span>
      </div>
    </div>
  </footer>
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>