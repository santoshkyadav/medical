<?php $__env->startSection('content'); ?>
<div class="graphs">
	<div id="content-wrapper">
		<div class="container-fluid">

			<div class="row col_3">
				<div class="col-md-3 widget widget1">
					<div class="r3_counter_box">
						<i class="pull-left fa fa-thumbs-up icon-rounded"></i>
						<div class="stats">
							<?php 
							$session = Session::all();
							$customers = DB::table('mstcustomer')->where('studio_id', '=',$session['studio_id'])->get();
							$totalcustomer = count($customers);
							$total_images = DB::table('tblfunctiondetail')->where('Studio_Id', '=', $session['studio_id'])->get();
							$total_count = 0;
							foreach($total_images as $function_id){
							$total_count++;
						}
						 ?>
						<h5><strong><?php echo e($total_count); ?></strong></h5>
						<span>Total Images</span>
					</div>
				</div>
			</div>
			<div class="col-md-3 widget widget1">
				<div class="r3_counter_box">
					<i class="pull-left fa fa-users user1 icon-rounded"></i>
					<div class="stats">
						<h5><strong><?php echo e($totalcustomer); ?></strong></h5>
						<span>Total Customers</span>
					</div>
				</div>
			</div>
			<div class="col-md-3 widget widget1">
				<div class="r3_counter_box">
					<i class="pull-left fa fa-comment user2 icon-rounded"></i>
					<div class="stats">
						<h5><strong>0</strong></h5>
						<span>Total Ebooks</span>
					</div>
				</div>
			</div>
			<div class="col-md-3 widget">
				<div class="r3_counter_box">
					<i class="pull-left fa fa-dollar dollar1 icon-rounded"></i>
					<div class="stats">
						<h5><strong>0</strong></h5>
						<span>Total EbookCustomer</span>
					</div>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
		<!-- ---------------div for table------------------------ -->
		<div class="content_bottom">
			<div class="col-md-8 span_3">
				<div class="bs-example1" data-example-id="contextual-table">
					<table class="table">
						<thead>
							<tr>
								<th>#</th>
								<th>Payment Date </th>
								<th>Subscriptio Tenure</th>
								<th>Start Date</th>
								<th>Expiry Date</th>
								<th>Amount Paid</th>
								<th>Payment Methord</th>
								<th>Studio ID</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$payment_details = DB::table('payment')->where('Studio_id', '=', $session['studio_id'])->get();
							$i= 1;
							 ?>
							<?php $__currentLoopData = $payment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $totalPaid_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<th scope="row"><?php echo e($i); ?></th>
								<td><?php echo e($totalPaid_user->PaymentDate); ?></td>
								<td><?php echo e($totalPaid_user->SubscriptionTenure); ?></td>
								<td><?php echo e($totalPaid_user->StartDate); ?></td>
								<td><?php echo e($totalPaid_user->ExpiryDate); ?></td>
								<td><?php echo e($totalPaid_user->AmountPaid); ?></td>
								<td><?php echo e($totalPaid_user->PaymentMethord); ?></td>
								<td><?php echo e($totalPaid_user->Studio_id); ?></td>
							</tr>
							<?php 
							$i++
							 ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>
				</div>
			</div>
			<div class="col-md-4 span_4">
				<div class="col_2">
					<div class="box_1">
						<div class="col-md-6 col_1_of_2 span_1_of_2">
							<a class="tiles_info" href="<?php echo e(url('user_dashboard/templatesummary')); ?>">
								<div class="tiles-head red1">
									<div class="text-center">
									Download Template </div>
								</div>
								<?php 
								$template = DB::table('template')->get();
									$totalcount = count($template);
								 ?>
								<div class="tiles-body red"><?php echo e($totalcount); ?></div>
							</a>

						</div>
						<div class="col-md-6 col_1_of_2 span_1_of_2">
							<a class="tiles_info tiles_blue" href="<?php echo e(url('user_dashboard/software')); ?>">
								<div class="tiles-head tiles_blue1">
									<div class="text-center">Download Software</div>
								</div>
								<?php 
								$software = DB::table('software')->get();
								$totalcount1 = count($software);
								 ?>
								<div class="tiles-body blue1"><?php echo e($totalcount1); ?></div>
							</a>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="box_1">
						<div class="col-md-6 col_1_of_2 span_1_of_2">
							<a class="tiles_info" href="<?php echo e(url('user_dashboard/clientdetail')); ?>">
								<div class="tiles-head fb1">
									<div class="text-center">Client Details</div>
								</div>
								<?php 
								$customer = DB::table('mstcustomer')->where('Studio_Id', '=', $session['studio_id'])->get();
								$totalcount2 = count($customer);
								 ?>
								<div class="tiles-body fb2"><?php echo e($totalcount2); ?></div>
							</a>
						</div>
						<div class="col-md-6 col_1_of_2 span_1_of_2">
							<a class="tiles_info tiles_blue">
								<div class="tiles-head tw1">
									<div class="text-center">Make Payment</div>
								</div>
								<div class="tiles-body tw2" data-toggle="modal" data-target="#myModal">Go</div>
							</a>
						</div>
						<!-- Modal -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog modal-lg">
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Studio Details</h4>
										<button type="button" class="close" data-dismiss="modal">&times;</button> 
									</div>
									<div class="modal-body">
										<?php 
										$studio = DB::table('studio')->where('id', '=', $session['studio_id'])->get();

										 ?>
										<form method="post" action="<?php echo e(url('payment')); ?>">
											<?php echo e(csrf_field()); ?>

											<div class="form-group">
												<label for="studio_name">Studio Name:</label>
												<input type="text" class="form-control" name="studio_name" value="<?php echo e($studio[0]->studio_name); ?>">
											</div>
											<div class="form-group">
												<label for="mob_no">Mobile Number:</label>
												<input type="text" class="form-control" name="mob_no" value="<?php echo e($studio[0]->mobile_no); ?>">
											</div>
											<div class="form-group">
												<label for="city">City</label>
												<input type="text" class="form-control" name="city" value="<?php echo e($studio[0]->city); ?>">
											</div>
											<div class="form-group">
												<label for="state">State:</label>
												<input type="text" class="form-control" name="state" value="<?php echo e($studio[0]->state); ?>">
											</div>
											<div class="form-group">
												<label for="payment_mode">Payment Mode: </label>
												<label class="radio-inline">
													<input type="radio" name="payment" value="1" checked>Online
												</label>
												<label class="radio-inline">
													<input type="radio" name="payment" value="2">Bank Deposite
												</label>
												<label class="radio-inline">
													<input type="radio" name="payment" value="3">At counter(Cash)
												</label>
											</div>
											<div class="form-group">
												<label for="payment_tenure">Payment tenure:</label>
												<select class="form-control" id="payment_tenure" name="payment_tenure">
													<option value="1">1 month</option>
													<option value="2">2 month</option>
													<option value="3">3 month</option>
													<option value="4">4 month</option>
													<option value="5">5 month</option>
													<option value="6">6 month</option>
													<option value="7">7 month</option>
													<option value="8">8 month</option>
													<option value="9">9 month</option>
													<option value="10">10 month</option>
													<option value="11">11 month</option>
													<option value="12">12 month</option>
												</select>
											</div>
											<div class="form-group">
												<label for="state">Amount:</label>
												<input type="text" class="form-control" name="amount" value="" id="amount">
												<?php if($errors->has('amount')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('amount')); ?></strong>
												</span>
												<?php endif; ?>
											</div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
											<button type="submit" class="btn btn-primary">MAKE PAYMENT</button>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- Modal -->
						
						<div class="clearfix"> </div>
					</div>
				</div>
				
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$('#payment_tenure').on('change', function(){
		var selected_month = $('#payment_tenure').val();
		var moneytopay = '<?php echo e(Config::get('app.payment_money')); ?>';
		var installment_money = moneytopay/selected_month;
		$('#amount').val(installment_money);

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>