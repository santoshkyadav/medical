<div id="wrapper" >
    <!-- Sidebar -->
    <div class="main_menu">
        <ul class="sidebar navbar-nav" style="background-color: #ffffff">
            <li class="nav-item user_nev active">
                <a class="nav-link" href="<?php echo e(url('/user_dashboard')); ?>">
                    <span class="sidebar_menu">Sidebar 1</span>
                </a>

            </li>
            
        </ul>
    </div>