<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FunctiondetailModel extends Model
{
    protected $table = 'tblfunctiondetail';
}
