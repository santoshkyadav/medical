<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerloginModel extends Model
{
    protected $table = 'mstcustomer';
    
}
