<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cashpaymentuser extends Model
{
    public $table = 'cashpaymentusers';
}
