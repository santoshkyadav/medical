<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudioListModel extends Model
{
    protected $table = 'studiolist';
}
