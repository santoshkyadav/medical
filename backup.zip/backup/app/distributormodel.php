<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class distributormodel extends Model
{
    protected $table="distributer";
    public $timestamps=false;
}
