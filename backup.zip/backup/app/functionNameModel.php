<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class functionNameModel extends Model
{
    protected $table = 'mstfunction';
}
