<div id="wrapper" >
    <!-- Sidebar -->

    <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{url('/user_dashboard')}}" class="active"><i class="fas fa-fw fa-tachometer-alt nav_icon"></i>Dashboard</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
