@include('admin_template.header')
@yield('content')
@include('admin_template.footer')
@yield('css')
@yield('js')

