@include('customer_template.header')
@include('customer_template.sidebar')
@yield('content')
@include('customer_template.footer')
@yield('css')
@yield('js')

