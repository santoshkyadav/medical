@include('user_template.header')
@yield('content')
@include('user_template.footer')
@yield('css')
@yield('js')

